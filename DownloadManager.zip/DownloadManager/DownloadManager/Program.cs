﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace DownloadManager
{
    class Program
    {
        static int x = 0;

        static void Main(string[] args)
        {
            Thread.Sleep(1000);
            start();
        }

        static void start()
        {
            Console.Clear();
            Thread.Sleep(500);
            try
            {
                Console.WriteLine("Checking...");
                Console.Write(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Download\\Build - ");
                if (Directory.Exists(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Download\\Build"))
                {
                    Console.WriteLine("OK");
                    Console.WriteLine("Progressing...");
                    if (Directory.Exists(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build"))
                    {
                        Directory.Delete(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build", true);
                    }
                    Directory.Move(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Download\\Build", Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build");
                    ProcessStartInfo startInfo = new ProcessStartInfo(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build\\CrystalUmbrella.net.exe");
                    Process.Start(startInfo);
                    Console.WriteLine("Progressed and Started!");
                    Thread.Sleep(500);
                }
                else
                {
                    if (x < 5)
                    {
                        x += 1;
                        start();
                    }
                    else
                    {
                        Console.WriteLine("ERROR");
                        Console.WriteLine("");
                        Console.WriteLine("Press Enter to close program...");
                        Console.ReadLine();
                    }
                }
            }
            catch
            {
                if (x < 5)
                {
                    x += 1;
                    start();
                }
                else
                {
                    Console.WriteLine("ERROR");
                    Console.WriteLine("");
                    Console.WriteLine("Press Enter to close program...");
                    Console.ReadLine();
                }
            }
        }
    }
}
