﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace DownloadManager
{
    class Program
    {
        static void Main(string[] args)
        {
            start();
        }

        static void start()
        {
            try
            {
                Console.WriteLine("Checking...");
                Console.Write(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Download\\Build - ");
                while (!Directory.Exists(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Download\\Build")) { Thread.Sleep(100); }
                if (Directory.Exists(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Download\\Build"))
                {
                    Console.WriteLine("OK");
                    Console.WriteLine("Progressing...");
                    if (Directory.Exists(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build"))
                    {
                        Directory.Delete(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build", true);
                    }
                    Directory.Move(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Download\\Build", Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build");
                    while (!File.Exists(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build\\CrystalUmbrella.net.exe")) { Thread.Sleep(100); }
                    ProcessStartInfo startInfo = new ProcessStartInfo(Environment.CurrentDirectory[0] + ":\\CrystalUmbrella.net\\Client\\Build\\CrystalUmbrella.net.exe");
                    Process.Start(startInfo);
                    Console.WriteLine("Progressed and Started!");
                    Thread.Sleep(500);
                }
                else
                {
                    Console.WriteLine("ERROR");
                    Console.WriteLine("");
                    Console.WriteLine("Press Enter to close program...");
                    Console.ReadLine();
                }
            }
            catch
            {
                Console.WriteLine("ERROR");
                Console.WriteLine("");
                Console.WriteLine("Press Enter to close program...");
                Console.ReadLine();
            }
        }
    }
}
